class myStackUsingDynamicArray{

    private dynamicArray A;
    private int stackSize;
    //Other variables to be defined by student
    
    public myStackUsingDynamicArray(){
        A = new dynamicArray();
        stackSize=0;
        //Othe initializations to be done by student
    }
    
    //This method should return the size of the stack
    public int getSize(){
        return stackSize;
        //To be written by student
    }
    public int getElement(int index){
        return A.getElement(index);
    }
    public int dynamicArraySize(){
        return A.getSize();
    }
    
    //This should implement the push operation of stack
    public void push(int value){
        if(stackSize==A.getSize()) A.doubleSize();
    A.modifyElement(value,stackSize);
    stackSize+=1;
        //To be written by student
    }
    
    //This should implement the pop operation of stack.
    //This method should throw an exception in case the stack is empty.
    public int pop(){
        int c=A.getElement(stackSize-1);
        stackSize-=1;
        if (2*stackSize<A.getSize()){
            A.halveSize();
        }
        return c;
        //To be written by student
    } 
    
}