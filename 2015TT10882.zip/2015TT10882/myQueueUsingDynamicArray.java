class myQueueUsingDynamicArray{

    private dynamicArray A;
    private int queueSize;

    //Other variables to be defined by student
    
    public myQueueUsingDynamicArray(){
        A = new dynamicArray();
        queueSize=0;
        //Othe initializations to be done by student
    }
    
    //This method should return the number of elements in the queue
    public int getSize(){  //***********
        return queueSize;
        //To be written by student
    }
    public int getElement(int index){ //*************
        return A.getElement(index);
    }
    public int dynamicArraySize(){
        return A.getSize();
    }
    
    //This should implement the enqueue operation of Queue
    public void enqueue(int value){
        if(queueSize==A.getSize()) A.doubleSize();
    A.modifyElement(value,queueSize);
    queueSize+=1;
        //To be written by student
    }
    
    //This should implement the dequeue operation of Queue
    //This method should throw an exception in case the queue is empty.
    public int dequeue(){
        if (queueSize==0) {System.out.println("queue is already empty");
            }
        //To be written by student
        
        int c=A.getElement(0);
        for (int i=0;i<queueSize-1; i++){
            A.modifyElement(A.getElement(i+1),i);
        }
        queueSize-=1;
        if (2*queueSize<A.getSize()){
            A.halveSize();
        }
        return c;
        
    }   
    
}